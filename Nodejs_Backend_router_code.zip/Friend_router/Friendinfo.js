
/** @module newFriend */
/*
const User = require('../../models/User');

function Friendinfo(req, res)
{
    const Friend_Email = req.body.email;
    User.findOne({email : Friend_Email})
        .then(user => {
            if(!user){
                console.log(user);
                errors = "해당하는 회원이 존재하지 않습니다.";
                return res.status(400).json(errors);
            }
            res.status(200).json({
                id : 
            })
        });
    
}

module.exports.Friendinfo = Friendinfo;
*/